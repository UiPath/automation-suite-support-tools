#!/bin/bash

SCRIPTDIR=$(dirname "$0")
if [ -d "$SCRIPTDIR/../../Modules/" ]; then
    MODULESPATH="$SCRIPTDIR/../../Modules"
else
    MODULESPATH="$SCRIPTDIR/Modules/"
fi

source $MODULESPATH/systemUtils/systemUtils.sh
source $MODULESPATH/kubectlUtils/kubectlUtils.sh

usage() {
    echo "Usage: $0 [directory]"
    echo "Example: $0 /backup/ceph"
    exit 1
}


# Create a directory for storing the backup script
create_backup_script_Dir() {
    echo "Creating directory for backup script"
    cmd="sudo mkdir -p /opt/UiPathAutomationSuite/cephBackupScript"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to create directory for backup script"
        echo "Error: $CMD_ERR"
        exit 1
    fi

    echo ""
}

# mvoe the backup script from the scripdir/package to the backup script directory
move_backup_script() {
    echo "Moving backup script to backup script directory"
    cmd="sudo cp $SCRIPTDIR/cephBackup/objectstore-migration.sh /opt/UiPathAutomationSuite/cephBackupScript/"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to move backup script to backup script directory"
        echo "Error: $CMD_ERR"
        exit 1
    fi

    echo ""
}

# set permissions on the backup setup directory
set_backup_script_permissions() {
    echo "Setting permissions on backup script"
    cmd="sudo chmod 755 /opt/UiPathAutomationSuite/cephBackupScript/objectstore-migration.sh"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to set permissions on backup script"
        echo "Error: $CMD_ERR"
        exit 1
    fi

    echo ""
}

# Create system cronjob for executing the backup script
create_ceph_backup_cronjob() {
    echo "Creating cronjob for ceph backup"
    cmd="sudo crontab -l | { cat; echo \"0 * * * * CEPH_OPERATION=backup CEPH_BACKUP_PATH=$DIR /opt/UiPathAutomationSuite/cephBackupScript/objectstore-migration.sh\"; } | sudo crontab -"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to create cronjob for ceph backup"
        echo "Error: $CMD_ERR"
        exit 1
    fi

    # Check if the cronjob was created
    cmd="sudo crontab -l | grep \"objectstore-migration.sh\""
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to create cronjob for ceph backup"
        echo "Error: $CMD_ERR"
        exit 1
    fi

    echo ""
}


# check the available size of the backup directory
check_backup_directory_size() {
    echo "Checking backup directory size"
    cmd="sudo df --output=avail -B1 $DIR"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to check backup directory size"
        echo "Error: $CMD_ERR"
        exit 1
    fi

    BACkUP_DIR_SIZE=$CMD_OUT
    BACkUP_DIR_SIZE=$(echo $BACkUP_DIR_SIZE | tail -n 1)
    BACkUP_DIR_SIZE=${BACkUP_DIR_SIZE/Avail/}

    echo "Directory size: $BACkUP_DIR_SIZE"

    echo ""
}

check_ceph_storage_usage() {
    echo "Checking ceph storage usage"
    cmd="-n rook-ceph exec deploy/rook-ceph-tools -- ceph status --format json"
    kubectlCmd "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to check ceph storage usage"
        echo "Error: $CMD_ERR"
        exit 1
    fi

    # THe previous command should error if no results are retunred. So we can assume we got a response
    # and we can parse it for the storage usage using pipes with pipe fail
    cmd="echo '$CMD_OUT' | jq -r '.pgmap.data_bytes'"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to parse ceph storage usage"
        echo "Error: $CMD_ERR"
        exit 1
    fi

    CEPH_STORAGE_USAGE=$CMD_OUT
    echo ""
}

compare_ceph_storage_to_backup() {
    echo "Comparing ceph storage usage to backup directory size"
    if [ "$CEPH_STORAGE_USAGE" -gt "$BACkUP_DIR_SIZE" ]; then
        echo "Ceph storage usage is greater than backup directory size"
        echo "Ceph storage usage: $CEPH_STORAGE_USAGE"
        echo "Backup directory size: $BACUP_DIR_SIZE"
        echo "Please increase the size of the backup directory"
        exit 1
    else
        echo "Ceph storage usage is less than backup directory size"
        echo "Ceph storage usage: $CEPH_STORAGE_USAGE"
        echo "Backup directory size: $BACUP_DIR_SIZE"
    fi

    echo ""
}


# Check if an argument was provided
if [ $# -ne 1 ]; then
    usage
fi

DIR=$1

# Check if the provided argument is a directory
if [ ! -d "$DIR" ]; then
    echo "Error: $DIR is not a directory"
    usage
fi

# Check if the provided directory is empty
check_ceph_storage_usage
check_backup_directory_size
compare_ceph_storage_to_backup
create_backup_script_Dir
move_backup_script
set_backup_script_permissions
create_ceph_backup_cronjob