# systemUtils.sh#
#
#   NOTE: Since bash does not support objects, will will write everything to standard error for log messages
#   and standard out for the actual output of the function
#
export EXIT_BEHAVIOR=1
test_tmp_write_access() {
    echo "Testing write access to /tmp" >&2
    # Create a temporary file in /tmp
    TMP_FILE="/tmp/test_write_access_$(date +%s%N).tmp"

    # Try to write to the temporary file
    if echo "test" > "$TMP_FILE"; then
        echo "Write access to /tmp confirmed." >&2
        # Cleanup the test file
        rm -f "$TMP_FILE"
    else
        echo "Failed to write to /tmp." >&2
        exit_or_return
        return 1
    fi

    echo "" >&2
}


execute_command() {

    # Check if we want logging. If so, log the command
    if [ -z "$2" ]; then
            echo "Executing: $1" >&2
    fi

    # Create temporary files for stdout and stderr
    TMP_OUT=$(mktemp)
    TMP_ERR=$(mktemp)

    # Execute command and redirect outputs to temporary files
    eval "$1" > "$TMP_OUT" 2> "$TMP_ERR"
    CMD_EXIT_CODE=$?

    # Capture outputs from temporary files into the variables
    CMD_OUT=$(cat "$TMP_OUT")
    CMD_ERR=$(cat "$TMP_ERR")

    # Cleanup temporary files
    rm -f "$TMP_OUT" "$TMP_ERR"

}

get_exit_code() {
    echo $CMD_EXIT_CODE
}

get_output() {
    echo $CMD_OUT
}

get_error() {
    echo $CMD_ERR
}

exit_or_return() {
    if [ "$EXIT_BEHAVIOR" -eq 1 ]; then
        exit 1
    else
        return 
    fi
}

set_exit_behavior() {
    EXIT_BEHAVIOR="$1"
}

prompt() {
    # Prompt the user
    read -p "Do you want to continue? (y/n) " answer

    # Check their answer
    case $answer in
        [Yy]* ) 
            echo "User agreed to continue." >&2
            CMD_EXIT_CODE=0
            # Place the rest of your script commands here
            ;;
        [Nn]* )
            echo "User declined to continue." >&2
            CMD_EXIT_CODE=1
            exit_or_return
            return 1
            ;;
        * )
            echo "Invalid input provided." >&2
            CMD_EXIT_CODE=1
            exit_or_return
            return 1
            ;;
    esac

    echo "" >&2
}

