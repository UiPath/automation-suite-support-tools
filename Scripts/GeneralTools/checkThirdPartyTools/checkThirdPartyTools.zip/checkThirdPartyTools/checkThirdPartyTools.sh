#!/bin/bash

SCRIPTDIR=$(dirname "$0") 
if [ -d "$SCRIPTDIR/../../Modules/" ]; then
    MODULESPATH="$SCRIPTDIR/../../Modules"
else
    MODULESPATH="$SCRIPTDIR/Modules/"
fi

source $MODULESPATH/systemUtils/systemUtils.sh


if [ -d "$SCRIPTDIR/../../Configs/" ]; then
    CONFIGS="$SCRIPTDIR/../../Configs/"
else
    CONFIGS="$SCRIPTDIR/Configs/"
fi

CONFIGSOURCE="$CONFIGS/checkThirdPartyTools"
#
#   This is a script that can be ran on a host to check the third party tools
#
#   This is the way it works:
#   1.  it will run the command systemctl list-units --type=service and output it to a temp file
#   2.  It will compare this to the file $CONFIGS/checkThirdPartyTools.json. 
#       This file will have the services that could cause issues. Its a json file with a key which reprensets the service name
#       and a description of problems the service can cause.
#   3.  The kye from the json file will be used to check the results of systemctl list-units --type=service.
#       If the service is found, the description will be printed along with the service name as returned from systemctl list-units --type=service

#
#   This function will print the help message
#
printUsage() {
    echo "Usage: $0 [options]"
    echo "Description: This script will check the third party tools that could cause issues."
    echo "             The list is based on customer reports where we have found these"
    echo "             services were causing issues. "
    echo ""
    echo "             If a service is returned, it means that it might be causing an issue"
    echo "             and should be investigated. It does not mean the service is incompatible"
    echo "             with Automation Suite."
    echo ""
    echo "             We recomend disabling the tool to see if the issue is resolved. If it is,"
    echo "             then the tool may be misconfigured or you may need to work with the vendor"
    echo "             to resolve the issue."         
    echo "Options:"
    echo "  -h | --help : This will print the help message."
    echo "  -l | --list : This will list the services that could cause issues."
    exit 0
}

#
#
#
parseArgs() {
    while [ "$#" -gt 0 ]; do
        case "$1" in
            -h|--help)
                printUsage
                ;;
            -l|--list)
                listThirdPartyTools
                exit 0
                ;;
            *)
                echo "Unknown option: $1" >&2
                printUsage
                ;;
        esac
    done
}

#
#   Get the systemctl list-units --type=service and output it to a temp file
#
function getSystemctlListUnits() {
    local cmd="systemctl list-units --type=service > /tmp/systemctlListUnits"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to get systemctl list-units --type=service" >&2
        echo "ERROR: $CMD_ERR" >&2
        exit_or_return
        return 1
    fi

    echo ""
}

#
#   This function will check the systemctl list-units --type=service against the json file
#
function checkThirdPartyTools() {
    local cmd="cat $CONFIGS/checkThirdPartyTools/thirdPartyTools.json"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to get checkThirdPartyTools.json" >&2
        echo "ERROR: $CMD_ERR" >&2
        exit_or_return
        return 1
    fi
    local thirdpartyTools=$(echo $CMD_OUT)
    local services=$(echo $CMD_OUT | jq -r 'keys[]')

    getSystemctlListUnits

    echo "Listing potential third party tools that could cause issues"
    echo ""
    for service in $services; do
        local cmd="grep $service /tmp/systemctlListUnits"
        execute_command "$cmd" 0

        if [ "$CMD_EXIT_CODE" -eq 0 ]; then
            local unitfile=$(echo $CMD_OUT | awk '{print $1}')
            local description=$(echo $thirdpartyTools | jq -r ".\"$service\"")
            echo "Service: $unitfile"
            echo "Description: $description"
            echo "To stop the service run: systemctl stop $unitfile"
            echo ""
        fi
    done

    echo "If any services were found, try the following:"
    echo -e "\tOrder of operations should be: Stop offending service, then restart Automation Suite services (its important to run rke2-killall.sh so iptables rules are reloaded)"
    echo -e "\tOn all nodes Disable the services this script returned: systemctl stop <service>"
    echo -e "\tRun the stop commands on each node as described here: https://docs.uipath.com/automation-suite/automation-suite/2023.10/installation-guide/starting-and-shutting-down-a-node"
    echo -e "\tRestart the Automation Suite services per the above document."
    echo -e "\tIf the issue is resolved, then the service may be misconfigured or incompatible with Automation Suite. Contact the vendor for support."
}

#
#  This function will simply print the third party tools that could cause issues
#
function listThirdPartyTools() {
    local cmd="cat $CONFIGS/checkThirdPartyTools/thirdPartyTools.json"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to get checkThirdPartyTools.json" >&2
        echo "ERROR: $CMD_ERR" >&2
        exit_or_return
        return 1
    fi
    local thirdpartyTools=$(echo $CMD_OUT)
    local services=$(echo $CMD_OUT | jq -r 'keys[]')

    echo "Listing potential third party tools that could cause issues"
    echo ""
    for service in $services; do
        local description=$(echo $thirdpartyTools | jq -r ".\"$service\"")
        echo "Service: $service"
        echo "Description: $description"
        echo ""
    done
}

parseArgs $@

# Check that the user is root or sudo
if [ "$EUID" -ne 0 ]; then
    echo "Please run as root or sudo" >&2
    exit 1
fi


checkThirdPartyTools