#!/bin/bash


SCRIPTDIR=$(dirname "$0") 
if [ -d "$SCRIPTDIR/../../Modules/" ]; then
    MODULESPATH="$SCRIPTDIR/../../Modules"
else
    MODULESPATH="$SCRIPTDIR/Modules/"
fi

source $MODULESPATH/systemUtils/systemUtils.sh
source $MODULESPATH/kubectlUtils/kubectlUtils.sh


if [ -d "$SCRIPTDIR/../../Configs/" ]; then
    CONFIGS="$SCRIPTDIR/../../Configs/"
else
    CONFIGS="$SCRIPTDIR/Configs/"
fi

#
#   This is used by the packaging script for building a zip package.
#
CONFIGSOURCE="$CONFIGS/networkPolicyTool"



# This is a script to manage a few things with network policies.
# It will do the following:
# - Create a network policy to allow all traffic in a specific namespace.
# - Create a network policy in all namespaces to allow all traffic.
# - Create a network policy based on a pre-defined file.
# - Remove a network policy based on a pre-defined file.
#
# The commands to this tool are:
# - allowAllTrafficGlobally | -G
# - allowAllTrafficInNamespace | -N <namespace>
# - createNetworkPolicy | -C <file>
# - add | -a 
# - remove | -r
# - help | -h
#

#
#   Parse the command line arguments. Use long opts.
#
function parse_long_args() {
  local PARAMS=""
    while (( "$#" )); do
        case "$1" in
        -g | --allowAllTrafficGlobally)
            PARAMS="$PARAMS -g"
            ALLOWALLTRAFFICGLOBALLY=1
            shift
            ;;
        -n | --allowAllTrafficInNamespace)
            if [ -n "$2" ]; then
            PARAMS="$PARAMS -n $2"
            ALLOWALLTRAFFICINNAMESPACE=1
            NAMESPACE=$2
            shift
            else
            echo "Error: Argument for $1 is missing" >&2
            exit 1
            fi
            shift
            ;;
        -c | --createNetworkPolicy)
            if [ -n "$2" ]; then
            PARAMS="$PARAMS -c $2"
            CREATENETWORKPOLICY=1
            NETWORKPOLICYFILE=$2
            shift
            else
            echo "Error: Argument for $1 is missing" >&2
            exit 1
            fi
            shift
            ;;
        -a | --add)
            PARAMS="$PARAMS -a"
            ADD=1
            shift
            ;;
        -r | --remove)
            PARAMS="$PARAMS -r"
            REMOVE=1
            shift
            ;;
        -h | --help)
            PARAMS="$PARAMS -h"
            shift
            display_usage
            ;;
        --) # end argument parsing
            shift
            break
            ;;
        -*|--*=) # unsupported flags
            echo "Error: Unsupported flag $1" >&2
            exit 1
            ;;
        *) # preserve positional arguments
            PARAMS="$PARAMS $1"
            shift
            ;;
        esac
    done
}

function display_usage() {
    echo "This is a tool for debugging network policies or applying fixes." >&2
    echo "Usage: networkPolicyTool.sh [OPTIONS]" >&2
    echo "Options:" >&2
    echo "  -g | --allowAllTrafficGlobally | -g                  Used to manage a network policy that allows all traffic in all namespaces." >&2
    echo "  -n | --allowAllTrafficInNamespace <namespace>        Used to manage a network policy that allows all traffic in a specific namespace." >&2
    echo "  -c | --createNetworkPolicy <file>                    Used to create a network policy based on a pre-defined configuration file." >&2
    echo "  -a | --add                                           Used to add a network policy." >&2      
    echo "  -r | --remove                                        Used to remove a network policy." >&2
    echo "  -h | --help                                          Display this help message." >&2
    echo "Examples:" >&2
    echo "  networkPolicyTool.sh --allowAllTrafficGlobally --add" >&2
    echo "  networkPolicyTool.sh --allowAllTrafficGlobally --remove" >&2
    echo "  networkPolicyTool.sh --allowAllTrafficInNamespace mynamespace --add" >&2
    echo "  networkPolicyTool.sh --allowAllTrafficInNamespace mynamespace --remove" >&2
    echo "  networkPolicyTool.sh --createNetworkPolicy mynetworkpolicy.yaml --add" >&2
    echo "  networkPolicyTool.sh --createNetworkPolicy mynetworkpolicy.yaml --remove" >&2
    echo "  networkPolicyTool.sh --help" >&2
    exit 0
}

#
#  Check that the command line arguments are valid.
#   The rules are:
# allowAllTrafficGlobally must be used with create or add but nothing else
# createNetworkPolicy must be used with add or remove but nothing else
# allowAllTrafficInNamespace must be used with add or remove but nothing else
# add or remove cannot be used by themselves
# # add and remove cannot be used together
# allowAllTrafficGlobally or createNetworkPolicy or allowAllTrafficInNamespace must be provied
function check_args() {
    if [[ $ALLOWALLTRAFFICGLOBALLY -eq 1 ]]; then
        if [[ $CREATENETWORKPOLICY -eq 1 || $ALLOWALLTRAFFICINNAMESPACE -eq 1 ]]; then
            echo "Error: --allowAllTrafficGlobally cannot be used with --createNetworkPolicy or --allowAllTrafficInNamespace" >&2
            exit 1
        fi
    fi

    if [[ $CREATENETWORKPOLICY -eq 1 ]]; then
        if [[ $ALLOWALLTRAFFICGLOBALLY -eq 1 || $ALLOWALLTRAFFICINNAMESPACE -eq 1 ]]; then
            echo "Error: --createNetworkPolicy cannot be used with --allowAllTrafficGlobally or --allowAllTrafficInNamespace" >&2
            exit 1
        fi

        if [[ ! -f $NETWORKPOLICYFILE ]]; then
            echo "Error: Network policy file $NETWORKPOLICYFILE does not exist." >&2
            exit 1
        fi
    fi

    if [[ $ALLOWALLTRAFFICINNAMESPACE -eq 1 ]]; then
        if [[ $ALLOWALLTRAFFICGLOBALLY -eq 1 || $CREATENETWORKPOLICY -eq 1 ]]; then
            echo "Error: --allowAllTrafficInNamespace cannot be used with --allowAllTrafficGlobally or --createNetworkPolicy" >&2
            exit 1
        fi
    fi

    if [[ $ALLOWALLTRAFFICGLOBALLY -eq 0 && $CREATENETWORKPOLICY -eq 0 && $ALLOWALLTRAFFICINNAMESPACE -eq 0 ]]; then
        echo "Error: --allowAllTrafficGlobally or --createNetworkPolicy or --allowAllTrafficInNamespace must be provided" >&2
        exit 1
    fi

    if [[ $ADD -eq 0 && $REMOVE -eq 0 ]]; then
        echo "Error: --add or --remove must be used" >&2
        exit 1
    fi

    if [[ $ADD -eq 1 && $REMOVE -eq 1 ]]; then
        echo "Error: --add and --remove cannot be used together" >&2
        exit 1
    fi

}


function addAllowAllTrafficGlobally() {
    echo "Adding network policy to allow all traffic globally." >&2

    echo "Getting name spaces." >&2
    kubectlCmd "get namespaces -o jsonpath='{.items[*].metadata.name}'"

    if [[ $CMD_EXIT_CODE -ne 0 ]]; then
        echo "Error: Failed to get namespaces." >&2
        exit 1
    fi
    NAMESPACES=$CMD_OUT

    for NAMESPACE in $NAMESPACES; do
        echo "Adding network policy to allow all traffic in namespace $NAMESPACE." >&2
        kubectlCmd "apply -f $CONFIGS/networkPolicyTool/allowAllTraffic.yaml -n $NAMESPACE"

        if [[ $CMD_EXIT_CODE -ne 0 ]]; then
            echo "Error: Failed to add network policy to allow all traffic in namespace $NAMESPACE." >&2
            exit 1
        fi

        echo "Network policy to allow all traffic in namespace $NAMESPACE added." >&2
    done

    echo "Network policy to allow all traffic globally added." >&2
    echo "" >&2
}

function removeAllowAllTrafficGlobally() {
    echo "Removing network policy to allow all traffic globally." >&2
    
    echo "Getting name spaces." >&2
    kubectlCmd "get namespaces -o jsonpath='{.items[*].metadata.name}'"

    if [[ $CMD_EXIT_CODE -ne 0 ]]; then
        echo "Error: Failed to get namespaces." >&2
        exit 1
    fi
    NAMESPACES=$CMD_OUT
    set_exit_behavior 0
    for NAMESPACE in $NAMESPACES; do
        echo "Removing network policy to allow all traffic in namespace $NAMESPACE." >&2
        kubectlCmd "delete -f $CONFIGS/networkPolicyTool/allowAllTraffic.yaml -n $NAMESPACE"

        if [[ $CMD_EXIT_CODE -ne 0 ]]; then
            echo "Error: Failed to remove network policy to allow all traffic in namespace $NAMESPACE." >&2
        fi

        echo "Network policy to allow all traffic in namespace $NAMESPACE removed." >&2
    done
    set_exit_behavior 1

    echo "Network policy to allow all traffic globally removed." >&2
    echo "" >&2
}

function addAllowAllTrafficInNamespace() {
    echo "Adding network policy to allow all traffic in namespace $NAMESPACE." >&2
    kubectlCmd "apply -f $CONFIGS/networkPolicyTool/allowAllTraffic.yaml -n $NAMESPACE"

    if [[ $CMD_EXIT_CODE -ne 0 ]]; then
        echo "Error: Failed to add network policy to allow all traffic in namespace $NAMESPACE." >&2
        exit 1
    fi

    echo "Network policy to allow all traffic in namespace $NAMESPACE added." >&2
}

function removeAllowAllTrafficInNamespace() {
    echo "Removing network policy to allow all traffic in namespace $NAMESPACE." >&2
    kubectlCmd "delete -f $CONFIGS/networkPolicyTool/allowAllTraffic.yaml -n $NAMESPACE"

    if [[ $CMD_EXIT_CODE -ne 0 ]]; then
        echo "Error: Failed to remove network policy to allow all traffic in namespace $NAMESPACE." >&2
        exit 1
    fi

    echo "Network policy to allow all traffic in namespace $NAMESPACE removed." >&2
}

function createNetworkPolicy() {
    echo "Creating network policy based on file $NETWORKPOLICYFILE." >&2
    kubectlCmd "apply -f $NETWORKPOLICYFILE"

    if [[ $CMD_EXIT_CODE -ne 0 ]]; then
        echo "Error: Failed to create network policy based on file $NETWORKPOLICYFILE." >&2
        exit 1
    fi

    echo "Network policy created based on file $NETWORKPOLICYFILE." >&2
}

function removeNetworkPolicy() {
    echo "Removing network policy based on file $NETWORKPOLICYFILE." >&2
    kubectlCmd "delete -f $NETWORKPOLICYFILE"

    if [[ $CMD_EXIT_CODE -ne 0 ]]; then
        echo "Error: Failed to remove network policy based on file $NETWORKPOLICYFILE." >&2
        exit 1
    fi

    echo "Network policy removed based on file $NETWORKPOLICYFILE." >&2
}

# Main
ALLOWALLTRAFFICGLOBALLY=0
ALLOWALLTRAFFICINNAMESPACE=0
CREATENETWORKPOLICY=0
ADD=0
REMOVE=0
NAMESPACE=""
FILE=""
parse_long_args "$@"

#
# Check the arguments
#
check_args

#
# Check if user is root
#
if [[ $EUID -ne 0 ]]; then
    echo "Error: This script must be run as root or with sudo" >&2
    exit 1
fi

if [[ $ALLOWALLTRAFFICGLOBALLY -eq 1 ]]; then
    if [[ $ADD -eq 1 ]]; then
        addAllowAllTrafficGlobally
    elif [[ $REMOVE -eq 1 ]]; then
        removeAllowAllTrafficGlobally
    fi
fi

if [[ $ALLOWALLTRAFFICINNAMESPACE -eq 1 ]]; then
    if [[ $ADD -eq 1 ]]; then
        addAllowAllTrafficInNamespace
    elif [[ $REMOVE -eq 1 ]]; then
        removeAllowAllTrafficInNamespace
    fi
fi

if [[ $CREATENETWORKPOLICY -eq 1 ]]; then
    if [[ $ADD -eq 1 ]]; then
        createNetworkPolicy
    elif [[ $REMOVE -eq 1 ]]; then
        removeNetworkPolicy
    fi
fi

exit 0