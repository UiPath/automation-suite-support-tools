#!/bin/bash


SCRIPTDIR=$(dirname "$0")
if [ -d "$SCRIPTDIR/../../Modules/" ]; then
    MODULESPATH="$SCRIPTDIR/../../Modules"
else
    MODULESPATH="$SCRIPTDIR/Modules/"
fi

source $MODULESPATH/systemUtils/systemUtils.sh

#
# Source KUBECTL
#
export PATH="$PATH:/usr/local/bin:/var/lib/rancher/rke2/bin"
export KUBECONFIG="/etc/rancher/rke2/rke2.yaml"

############################################################################
# General Kubectl Operations
############################################################################

#
#   Function to execute a kubectl command. It will log the command for us.
#
#   kubectlCmd "command"
#
#   Returns 0 if successful, 1 if failed
#
kubectlCmd () {
    local cmd="kubectl $1"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to execute kubectl command: $cmd" >&2
        echo "ERROR: $CMD_ERR" >&2
        exit_or_return
        return 1
    fi
}

############################################################################
# Pod Operations
############################################################################


#
#   Function to create a pod. 
#   It takes in the pod name and the yaml file to create the pod
#
createPod () {
    local podName=$1
    local podYaml=$2

    local cmd="kubectl create -f $podYaml"
    execute_command "$cmd"
}


#
#   Function to copy a file into a pod
#   It takes in the pod name, the source file and the destination file
#
copyIntoPod () {
    local podName=$1
    local sourceFile=$2
    local destinationFile=$3

    local cmd="kubectl cp $sourceFile $podName:$destinationFile"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to copy file $sourceFile to pod $podName" >&2
        echo "ERROR: $CMD_ERR" >&2
        echo "Try manually running the following command: $cmd" >&2
        exit_or_return
        return 1
    fi
}

############################################################################
# CronJob Operations
############################################################################

#
#   Function to disable a cronjob. It takes in the cronjob name and the namespace.
#
#   disableCronJob "namespace" "cronJobName"
#
#   Returns 0 if successful, 1 if failed
disableCronJob () {
    local namespace=$1
    local cronJobName=$2
    echo "Disabling cronjob $cronJobName in namespace $namespace" >&2
    local cmd="kubectl -n $namespace patch cronjob $cronJobName -p '{\"spec\" : {\"suspend\" : true}}'"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to disable cronjob $cronJobName" >&2
        echo "ERROR: $CMD_ERR" >&2
        exit_or_return
        return 1
    fi

    echo "Disabled cronjob $cronJobName" >&2
    echo "" >&2
}

############################################################################
# Config/Secret Operations
############################################################################

# 
#   Function to backup config map 
#   It takes in the namespace, name and the file to backup the config map to.
#
#   backupConfigMap "namespace" "configMapName" "configFile"
#
#   Return 0 if successful, 1 if failed
#
backupConfigMap() {
    local namespace=$1
    local configMapName=$2
    local configFile=$3
    echo "Backing up config map $2 in namespace $1 to $3" >&2

    local cmd="kubectl -n $namespace get configmap $configMapName -o json"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to backup configmap $configMapName in namespace $namespace" >&2
        echo "ERROR: $CMD_ERR" >&2
        exit_or_return
        return 1
    fi

    # Remove the uid, resourceVersion and creationTimestamp from the secret. This command will not fail if CMD_OUT is null but that would be unlikely.
    echo "Removing Metadata from the config map" >&2
    echo "Executing: echo ConfigVar | jq 'del(.metadata.uid, .metadata.resourceVersion, .metadata.creationTimestamp)'  > $configFile" >&2
    echo $CMD_OUT | jq 'del(.metadata.uid, .metadata.resourceVersion, .metadata.creationTimestamp)'  > $configFile

    if [ "$?" -ne 0 ]; then
        echo "Failed to backup configmap $configMap in namespace $namespace" >&2
        exit_or_return
        return 1
    fi
}

# TODO add function to get single secret

# Get all secrets names in a namespace
# TODO untested
# getSecrets () {
#     local namespace=$1
#     local cmd="kubectl -n $namespace get secrets  -o=jsonpath='{.items[*].metadata.name}'"
#     execute_command "$cmd"

#     if [ "$CMD_EXIT_CODE" -ne 0 ]; then
#         echo "Failed to get secrets in namespace $namespace" >&2
#         echo "ERROR: $CMD_ERR" >&2
#         exit_or_return
#         return 1
#     fi

#     echo "$CMD_OUT"
# }

#
#   Function to backup a secret. 
#   It takes in the namespace, name and the file to backup the secret to.
#
#   backupSecret "namespace" "secretName" "secretFile"
#
#   Return 0 if successful, 1 if failed
#
backupSecret() {
    
    local namespace=$1
    local secretName=$2
    local secretFile=$3
    echo "Backing up secret $2 in namespace $1 to $3" >&2

    local cmd="kubectl -n $namespace get secret $secretName -o json"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to backup secret $secretName in namespace $namespace" >&2
        echo "ERROR: $CMD_ERR" >&2
        exit_or_return
        return 1
    fi

    # Remove the uid, resourceVersion and creationTimestamp from the secret. This command will not fail if CMD_OUT is null but that would be unlikely.
    echo "Removing Metadata from the secret" >&2
    echo "Executing: echo SecretVar | jq 'del(.metadata.uid, .metadata.resourceVersion, .metadata.creationTimestamp)'  > $secretFile" >&2
    echo $CMD_OUT | jq 'del(.metadata.uid, .metadata.resourceVersion, .metadata.creationTimestamp)'  > $secretFile

    if [ "$?" -ne 0 ]; then
        echo "Failed to backup secret $secretName in namespace $namespace" >&2
        exit_or_return
        return 1
    fi
}




############################################################################
# UiPath Specific Operations
############################################################################

#
#   UNTESTED -TODO
#   Function to get the uipath version
#   
#   local version=$(getUiPathVersion)
#   
#   Returns the version or 1 if failed
#
# getUiPathVersion() {
#     local cmd="kubectl -n uipath-infra get cm | grep service-fabric-core"
#     execute_command "$cmd"
#
#     if [ "$CMD_EXIT_CODE" -ne 0 ]; then
#         echo "Failed to find service-fabric-core* in namespace uipath-infra" >&2
#         echo "ERROR: $CMD_ERR" >&2
#         exit_or_return
#         return 1
#     fi
#
#     # Parse the output for the version. It will always be in the format service-fabric-core-<version>. Store this as a variable
#     local version=$(echo "$CMD_OUT" | grep -oP "service-fabric-core-\K[0-9]+\.[0-9]+\.[0-9]+")
#     echo "$version"
# }

#
#   Function to get the uipath enabled services
#   
#   local enabledServices=$(getUiPathEnabledServices)
#
#   Returns the enabled services or 1 if failed
#
getUiPathEnabledServices() {
    echo "Getting the list of enabled services from uipath-infra namespace" >&2
    local cmd="kubectl -n uipath-infra get cm | grep service-fabric-core"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to find service-fabric-core-<version> cm in namespace uipath-infra" >&2
        echo "ERROR: $CMD_ERR" >&2
        exit_or_return
        return 1
    fi

    local configmap=$(echo "$CMD_OUT" | awk '{print $1}')

    # Make sure that configmap is not empty
    if [ -z "$configmap" ]; then
        echo "Failed to find service-fabric-core-<version> cm in namespace uipath-infra" >&2
        exit_or_return
        return 1
    fi

    # Get the list of enabled services from the configmap. Its loacated at data.enabled-services
    cmd="kubectl -n uipath-infra get cm $configmap -o=jsonpath='{.data.ENABLED_SERVICE_LIST}'"
    execute_command "$cmd"


    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to get enabled services in namespace uipath-infra" >&2
        echo "ERROR: $CMD_ERR" >&2
        exit_or_return
        return 1
    fi

    # Parese the output for the list of enabled services. Its a , seperated list. We want it as an array
    local enabledServices=$(echo "$CMD_OUT" | tr ',' '\n')

    echo "$enabledServices"

}

#
#   Function to get the uipath FQDN
#
#   local fqdn=$(getFQDN)
#
#   Returns the FQDN or 1 if failed
#
getFQDN() {
    local cmd="kubectl -n uipath-infra get cm | grep service-fabric-core"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to find service-fabric-core* in namespace uipath-infra" >&2
        echo "ERROR: $CMD_ERR" >&2
        exit_or_return
        return 1
    fi

    local configmap=$(echo "$CMD_OUT" | awk '{print $1}')

      # Make sure that configmap is not empty
    if [ -z "$configmap" ]; then
        echo "Failed to find service-fabric-core-<version> cm in namespace uipath-infra" >&2
        exit_or_return
        return 1
    fi

    # Get the FQDN
    cmd="kubectl -n uipath-infra get cm $configmap -o=jsonpath='{.data.FQDN}'"
    execute_command "$cmd"
     
    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to get enabled services in namespace uipath-infra" >&2
        echo "ERROR: $CMD_ERR" >&2
        exit_or_return
        return 1
    fi

    echo "$CMD_OUT"
}

#
#   Function to remove the hosts section of core DNS. Typically meant to be used in conjunction with setCoreDNSHostsOverride
#
#   removeCoreDNSHosts
#
#   Returns 0 if successful, 1 if failed
#
removeCoreDNSHosts() {
    echo "Removing the existing CoreDNS hosts, if it exists" >&2
    # First backup the coreDNS config
    local configFile="/tmp/coredns-configmap.json"
    backupConfigMap "kube-system" "rke2-coredns-rke2-coredns" $configFile

    local newFile="/tmp/coredns-configmap-new.json"

    echo "Removing Last applied from the config map" >&2
    echo "Executing: cat $configFile | jq 'del(.metadata.annotations.\"kubectl.kubernetes.io/last-applied-configuration\")'  > $newFile" >&2
    cat $configFile | jq 'del(.metadata.annotations."kubectl.kubernetes.io/last-applied-configuration")' > $newFile

    if [ "$?" -ne 0 ]; then
        echo "Failed to remove last applied from coredns configmap" >&2
        exit_or_return
        return 1
    fi

    # remove the hosts section from the coreDNS config backup using sed. Write the change to a new file
    
    echo "Removing hosts from coredns configmap: sed -zi 's/hosts {.*fallthrough\\\\n }//' $newFile" >&2
    sed -zi 's/hosts {.*fallthrough\\n }//' $newFile

    if [ "$?" -ne 0 ]; then
        echo "Failed to remove hosts from coredns configmap" >&2
        exit_or_return
        return 1
    fi

    # replace the configmap with the new file
    local cmd="kubectl -n kube-system replace --force -f $newFile"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to remove hosts from coredns configmap" >&2
        echo "ERROR: $CMD_ERR" >&2
        exit_or_return
        return 1
    fi

    # Normally we would remove the files but this inthis case we will not.

    echo "Removed hosts from coredns configmap"
    echo ""

}

#
#   Function to override the core DNS config for all Automation Suite URLS.
#   
#   setCoreDNSHostsOverride "ip" "domain"
#
#   Returns 0 if successful, 1 if failed
#
setCoreDNSHostsOverride() {
    local ip=$1
    local domain=$2
     echo "Adding the CoreDNS hosts override. Will map $ip to *.$domain" >&2

local corefile=$(cat <<EOF
{
    "data": {
        "Corefile": ".:53 {\n    errors\n    health {\n        lameduck 5s\n    }\n    ready\n    kubernetes cluster.local cluster.local in-addr.arpa ip6.arpa {\n        pods insecure\n        fallthrough in-addr.arpa ip6.arpa\n        ttl 30\n    }\n    prometheus 0.0.0.0:9153\n    forward . /etc/resolv.conf\n    cache 30\n    loop\n    reload\n    loadbalance\n    hosts {\n        $ip $domain\n        $ip insights.$domain\n        $ip alm.$domain\n        $ip monitoring.$domain\n        $ip registry.$domain\n        $ip objectstore.$domain\n        fallthrough\n    }\n}"
    }
}
EOF
)
    # Write the new corefile to a temp file. Make it a random file
    local tempFile=$(mktemp)
    echo "$corefile" > $tempFile

    if [ "$?" -ne 0 ]; then
        echo "Failed to write new coredns configma temp file" >&2
        echo "This probably means /tmp was not writable" >&2
        exit_or_return
        return 1
    fi

    local cmd="kubectl -n kube-system patch cm rke2-coredns-rke2-coredns --type merge --patch-file $tempFile"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to patch coredns configmap" >&2
        echo "ERROR: $CMD_ERR" >&2
        exit_or_return
        return 1
    fi

    echo "Patched coredns configmap"
    echo ""
}

#
#   Function to get the sf utils image
#
#   local sfUtilsImage=$(getsfUtilsImage)
#
#   Returns the image or 1 if failed
#
getsfUtilsImage () {
    local cmd="kubectl -n uipath-infra get cronjobs fluentd-logs-cleanup  -o jsonpath='{.spec.jobTemplate.spec.template.spec.containers[0].image}'"
    execute_command "$cmd"
    
    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to get sf utils image" >&2
        echo "ERROR: $CMD_ERR" >&2
        echo "Try manually running the following command: $cmd" >&2
        exit_or_return
        return 1
    fi
}



