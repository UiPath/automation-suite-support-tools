#!/bin/bash

set -o pipefail
SCRIPTDIR=$(dirname "$0") 
if [ -d "$SCRIPTDIR/../../Modules/" ]; then
    MODULESPATH="$SCRIPTDIR/../../Modules"
else
    MODULESPATH="$SCRIPTDIR/Modules/"
fi

source $MODULESPATH/systemUtils/systemUtils.sh
source $MODULESPATH/kubectlUtils/kubectlUtils.sh
source $MODULESPATH/rookCephUtils/rookCephUtils.sh
source $MODULESPATH/s3Utils/s3Utils.sh

if [ -d "$SCRIPTDIR/../../Configs/" ]; then
    CONFIGS="$SCRIPTDIR/../../Configs/"
else
    CONFIGS="$SCRIPTDIR/Configs/"
fi

CONFIGSOURCE="$CONFIGS/cephManager"

YAMLFILE=""

#
#   This is a script used to help manage ceph cluster storage.
#
#   It takes as input a command and a set of arguments and performs the command on the ceph cluster.
#   The commands are:
#   -s | --storageStats   Display the storage stats.
#   -cleanSFLogs | -cs    Clean the sf logs.
#   -cleanPipeline | -cp  Clean the pipeline logs and artifacts.


#
# Parse the command line arguments
#
function parseArgs() {
    while [ "$1" != "" ]; do
        case $1 in
            -s | --storageStats )   STORAGESTATS=true
                                    ;;
            -cs | --cleanSFLogs )    CLEANSFLOGS=true
                                    ;;
            -cp | --cleanPipeline )  CLEANPIPELINE=true
                                    ;;
            -a  |  --aicenterStats )  AICENTERSTATS=true
                                    ;; 
            -ds | --cleanDatasets )  CLEANDATASETS=true
                                    ;;                       
            -h | --help )           usage
                                    exit
                                    ;;
            * )                     usage
                                    exit 1
        esac
        shift
    done
}

#
#   Check the command line args.
#   All arguments are exclusive
#
function checkArgs() {
    if { [ "$STORAGESTATS" = true ] || [ "$AICENTERSTATS" = true ]; } && [ "$CLEANSFLOGS" = true ]; then
        echo "Error: -s and -cleanSFLogs are exclusive. Please specify only one."
        exit 1
    fi

    if { [ "$STORAGESTATS" = true ] || [ "$AICENTERSTATS" = true ]; } && [ "$CLEANPIPELINE" = true ]; then
        echo "Error: -s | -a and -cleanPipeline are exclusive. Please specify only one."
        exit 1
    fi

        if { [ "$STORAGESTATS" = true ] || [ "$AICENTERSTATS" = true ]; } && [ "$CLEANDATASETS" = true ]; then
        echo "Error: -s | -a and -cleanDatasets are exclusive. Please specify only one."
        exit 1
    fi

    if [ "$CLEANSFLOGS" = true ] && [ "$CLEANPIPELINE" = true ]; then
        echo "Error: -cleanSFLogs and -cleanPipeline are exclusive. Please specify only one."
        exit 1
    fi

    if [ "$CLEANSFLOGS" = true ] && [ "$CLEANDATASETS" = true ]; then
        echo "Error: -cleanSFLogs and -cleanPipeline are exclusive. Please specify only one."
        exit 1
    fi

    if [ "$CLEANPIPELINE" = true ] && [ "$CLEANDATASETS" = true ]; then
        echo "Error: -cleanDatasets and -cleanPipeline are exclusive. Please specify only one."
        exit 1
    fi

    #
    # If nothing is defined, throw an error.
    #
    if [ -z "$STORAGESTATS" ] && [ -z "$AICENTERSTATS" ] && [ -z "$CLEANSFLOGS" ] && [ -z "$CLEANPIPELINE"  ] && [ -z "$CLEANDATASETS" ]; then
        echo "Error: No command specified."
        usage
        exit 1
    fi
}

#
#   Function to print usage statement.
#
function usage() {
    echo "Usage: $0 -s | --cleanSFLogs | --cleanPipeline"
    echo "  -s  | --storageStats         Display the storage stats."
    echo "  -a  | --aicenterStats        Display the aicenter storage stats."
    echo "  -cs | --cleanSFLogs          Clean the sf logs."
    echo "  -cp | --cleanPipeline        Clean the pipeline logs and artifacts."
    echo "  -ds | --cleanDatasets        Clean the datasets."
}

function isClusterHealthy() {
    echo "Verifying cluster is healthy"
    local cmd="-n rook-ceph get cephclusters.ceph.rook.io -o jsonpath='{.items[0].status.ceph.health}'"
    kubectlCmd "$cmd"

    if [ $CMD_EXIT_CODE -ne 0 ]; then
        echo "Error: Unable to get cluster health."
        exit 1
    fi

    if [ "$CMD_OUT" != "HEALTH_OK" ] && [ "$CMD_OUT" != "HEALTH_WARN" ]; then
        echo "Error: Cluster is not healthy. Please check the cluster health."
        exit 1
    fi

    echo "Cluster is healthy"
    echo ""
}

function aicenterStats() {
    echo "Checking if AiCenter is enabled"
    local cmd="-n argocd get applications aicenter"
    set_exit_behavior 0
    kubectlCmd "$cmd"
    set_exit_behavior 1

    if [ $CMD_EXIT_CODE -ne 0 ]; then
        echo "Ai Center is not installed."
        echo ""
        exit 1
    fi

    echo "Ai Center is installed."
    echo ""
    echo "Getting AiCenter storage stats"
    echo ""

    getAiCenterDataUsage
}

#
#   
#
function setCleanUpYaml() {
    local yamlfile=$1

    local utilsImage=$(getsfUtilsImage)
    if [ -z "$utilsImage" ]; then
        echo "Error: Unable to get the utils image."
        exit 1
    fi

    #
    #   Update the utils image in the yaml file. Don't modify the original file.
    #
    local tmpfile=$(mktemp /tmp/cleanup.XXXXXX)
    local cmd="cp $yamlfile $tmpfile"
    execute_command "$cmd"

    if [ $CMD_EXIT_CODE -ne 0 ]; then
        echo "Error: Unable to copy the yaml file."
        exit 1
    fi

    cmd="sed -i \"s|UTILS_IMAGE|$utilsImage|g\" $tmpfile"

    execute_command "$cmd"

    if [ $CMD_EXIT_CODE -ne 0 ]; then
        echo "Error: Unable to update the yaml file."
        exit 1
    fi

    YAMLFILE=$tmpfile
}


#
#  apply cleanup pod
#
function runCleanUp() {
    kubectlCmd "-n uipath-infra delete -f $YAMLFILE --ignore-not-found"
    local cmd="-n uipath-infra apply -f $YAMLFILE"
    kubectlCmd "$cmd"

    if [ $CMD_EXIT_CODE -ne 0 ]; then
        echo "Error: Unable to apply the cleanup pod."
        exit 1
    fi

    echo "Cleanup pod created successfully."
    echo ""
}

#
#   make sure Jq is installed
#
function checkJq() {
    local cmd="jq --version"
    execute_command "$cmd"

    if [ $CMD_EXIT_CODE -ne 0 ]; then
        echo "Error: jq is not installed. Please install jq."
        exit 1
    fi
}

# Check if the user is sudo or root
if [ "$EUID" -ne 0 ]; then
    echo "Please run as root or sudo"
    exit 1
fi

parseArgs $@
checkArgs
checkJq
isClusterHealthy

if [ "$STORAGESTATS" = true ]; then
    storageStats
fi

if [ "$AICENTERSTATS" = true ]; then
    aicenterStats
    echo ""
    echo "Usage Stats Explained: "
    echo -e "\tThe folder followed by train-data represents a tenant"
    echo -e "\tafter the tenant, we can have a project folder, a pipeline"
    echo -e "\tfolder or a logs folder. Projects are represented by a guid"
    echo -e "\tand contain the dataset used for training. Pipelines are"
    echo -e "\tpipeline logs and artifacts. Logs are the logs of the of"
    echo -e "\tskils."
    echo ""
    echo -e "\tPipelines can be delated with the -cp option on this script."
    echo ""
    echo -e "\tLogs do not usually need to be deleted"
    echo ""
    echo -e "\tDatasets can be deleted if only DU models are used. The"
    echo -e "\tdatasets stored in train-data are just exports from the "
    echo -e "\tlabeling sessions. They can be re-exported if needed."
    echo -e "\tHowever, its better to delete them through the UI."
    echo -e "\tTo delete them use the -ds option."
fi

if [ "$CLEANSFLOGS" = true ]; then
    setCleanUpYaml $CONFIGS/cephManager/sflogCleanup.yaml
    runCleanUp
    echo "Run: kubectl -n uipath-infra logs cleanup-old-logs -f" 
fi

if [ "$CLEANPIPELINE" = true ]; then
    setCleanUpYaml $CONFIGS/cephManager/pipelineCleanup.yaml
    runCleanUp
    echo "Run: kubectl -n uipath-infra logs cleanup-pipeline -f" 
fi

if [ "$CLEANDATASETS" = true ]; then
    echo "Cleaning datasets could cause data loss!"
    echo "The same operation can be done through the UI."
    echo "This should only be done in extreme cases."
    echo "Only continue if you know what you are doing"

    prompt
    setCleanUpYaml $CONFIGS/cephManager/cleanDatasets.yaml
    runCleanUp
    echo "Run: kubectl -n uipath-infra logs ai-center-dataset-cleanup -f" 
fi