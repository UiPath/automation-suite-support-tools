#!/bin/bash

SCRIPTDIR=$(dirname "$0")
if [ -d "$SCRIPTDIR/../../Modules/" ]; then
    MODULESPATH="$SCRIPTDIR/../../Modules"
else
    MODULESPATH="$SCRIPTDIR/Modules/"
fi

source $MODULESPATH/systemUtils/systemUtils.sh
source $MODULESPATH/kubectlUtils/kubectlUtils.sh


# get rook-ceph bucket s3 keys
getRookCephS3Keys () {
    local cmd="kubectl -n rook-ceph get secret rook-ceph-object-user-uipath -o jsonpath='{.data.AccessKey}' | base64 --decode"
    execute_command "$cmd"

    kubectl -n rook-ceph get secret aicenter-service-rook-ceph-secret -o jsonpath='{.data.OBJECT_STORAGE_ACCESSKEY}'
    local accessKey=$CMD_OUT

    cmd="kubectl -n rook-ceph get secret rook-ceph-object-user-uipath -o jsonpath='{.data.SecretKey}' | base64 --decode"
    execute_command "$cmd"
    local secretKey=$CMD_OUT

    echo "$accessKey $secretKey"
}