#!/bin/bash


SCRIPTDIR=$(dirname "$0") 
if [ -d "$SCRIPTDIR/../../Modules/" ]; then
    MODULESPATH="$SCRIPTDIR/../../Modules"
else
    MODULESPATH="$SCRIPTDIR/Modules/"
fi
source $MODULESPATH/systemUtils/systemUtils.sh
source $MODULESPATH/kubectlUtils/kubectlUtils.sh


##################################################################################################
#  OSD FUNCTIONS
##################################################################################################

#
#  This command will run get pods and search for all OSDs and then print there hosts by osd number
#
function getOSDhosts() {
    local osd=$1
    kubectlCmd " -n rook-ceph get pods -l app=rook-ceph-osd -o jsonpath='{.items[*].spec.nodeName}'"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to get OSD hosts" >&2
        echo "ERROR: $CMD_ERR" >&2
        exit_or_return
        return 1
    fi

    echo $CMD_OUT
    echo "" >&2

}


# 
#  This function will get the local OSDs. It takes no input.
#  It checks /var/lib/ceph/osd/ceph-* to get the osd(s) number
#
getLocalOSDs() {
    echo "Getting local OSDs" >&2
    local cephHostDir="/var/lib/ceph/osd/"
    local cmd="ls /var/lib/rook/rook-ceph/set*"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to get local OSDs" >&2
        echo "ERROR: $CMD_ERR" >&2
        exit_or_return
        return 1
    fi

    # For each osd found, get the osd number
    for osd in $CMD_OUT; do
        osd=${osd#ceph-}
        osds="$osds $osd"
    done

    echo $osds
    echo "" >&2
}

#
#  Get all OSDS
#
function getOSDs() {
    echo "Getting OSDs" >&2
    kubectlCmd " -n rook-ceph get pods -l app=rook-ceph-osd -o jsonpath='{.items[*].metadata.name}'"
    echo $CMD_OUT
    echo "" >&2
}


#
#   rebuildMonFromOSds
#
function rebuildMonFromOSds() {
    echo "Rebuilding mon from OSDs" >&2
    echo "" >&2

    #
    # Make tmp dir
    #
    local localMonDir=$(mktemp -d)


    local osd_pods=$(getOSDs)
    for osd_pod in $osd_pods; do
        kubectlCmd " -n rook-ceph cp $localMonDir $osd_pod:/tmp/monRebuild"
        kubectlCmd " -n rook-ceph exec $osd_pod -- sh -c 'for ceph in /var/lib/ceph/osd/ceph-*; do ceph-objectstore-tool --data-path \$ceph --op update-mon-db --mon-store-path /tmp/monRebuild; done'"
        rm -rf $localMonDir
        kubectlCmd " -n rook-ceph cp $osd_pod:$localMonDir $localMonDir"
    done

    echo "Mon rebuild complete" >&2
    echo "" >&2
}

#
# Get the OSD deployment
#
function getOSDDeployment() {
    echo "Getting OSD deployment" >&2
    kubectlCmd " -n rook-ceph get deployments -l app=rook-ceph-osd -o jsonpath='{.items[*].metadata.name}'"
    echo $CMD_OUT
    echo "" >&2
}

#
# Put the OSD deployments in recovery
#
function putOsdsInRecovery() {
    echo "Putting OSD deployments in recovery" >&2

    # Get the OSD deployment name by parsing the osd pod name
    local osdDeployments=$(getOSDDeployment)

    if [ -z "$osdDeployments" ]; then
        echo "No OSD deployments found" >&2
        exit_or_return
        return 1
    fi
    # Use --type=json -p='[{"op": "replace", "path": "/spec/template/spec/containers/0/command", "value":["sleep", "10000"]}]'
    for osdDeployment in $osdDeployments; do
        kubectlCmd " -n rook-ceph patch deployment $osdDeployment --type='json' -p='[{\"op\": \"replace\", \"path\": \"/spec/template/spec/containers/0/command\", \"value\": [\"sleep\"]},{\"op\": \"replace\", \"path\": \"/spec/template/spec/containers/0/args\", \"value\": [\"1000\"]}]'"
    done
    echo "" >&2
}

function rollBackOsds() {
    echo "Rolling back OSD deployments" >&2

    # Get the OSD deployment name by parsing the osd pod name
    local osdDeployments=$(getOSDDeployment)

    if [ -z "$osdDeployments" ]; then
        echo "No OSD deployments found" >&2
        exit_or_return
        return 1
    fi

    for osdDeployment in $osdDeployments; do
        # Undo the deployment by going back a revision
        kubectlCmd " -n rook-ceph rollout undo deployment $osdDeployment"
    done
    echo "" >&2
}

function getMonDeployments() {
    echo "Getting Mon deployments" >&2
    kubectlCmd " -n rook-ceph get deployments -l app=rook-ceph-mon -o jsonpath='{.items[*].metadata.name}'"
    echo $CMD_OUT
    echo "" >&2
}

function putMonsInRecovery() {
    echo "Putting Mon deployments in recovery" >&2

    # Get the Mon deployment name by parsing the mon pod name
    local monDeployments=$(getMonDeployments)

    if [ -z "$monDeployments" ]; then
        echo "No Mon deployments found" >&2
        exit_or_return
        return 1
    fi

    for monDeployment in $monDeployments; do
        kubectlCmd " -n rook-ceph patch deployment $monDeployment --type='json' -p='[{\"op\": \"replace\", \"path\": \"/spec/template/spec/containers/0/command\", \"value\": [\"sleep\"]},{\"op\": \"replace\", \"path\": \"/spec/template/spec/containers/0/args\", \"value\": [\"1000\"]}]'"
    done
    echo "" >&2
}

function rollBackMons() {
    echo "Rolling back Mon deployments" >&2

    # Get the Mon deployment name by parsing the mon pod name
    local monDeployments=$(getMonDeployments)

    if [ -z "$monDeployments" ]; then
        echo "No Mon deployments found" >&2
        exit_or_return
        return 1
    fi

    for monDeployment in $monDeployments; do
        # Undo the deployment by going back a revision
        kubectlCmd " -n rook-ceph rollout undo deployment $monDeployment"
    done
    echo "" >&2

}

function putOperatorInRecovery() {
    echo "Putting operator in recovery" >&2
    
    # Scale down the operator
    kubectlCmd " -n rook-ceph scale deployment rook-ceph-operator --replicas=0"
    echo "" >&2
}

function rollBackOperator() {
    echo "Rolling back operator" >&2

    # Scale up the operator
    kubectlCmd " -n rook-ceph scale deployment rook-ceph-operator --replicas=1"
    echo "" >&2
}

##################################################################################################
#  AUTH KEY FUNCTIONS
##################################################################################################

#
# This function gets the local osds, and then it gets the auth key for each osd and then it sets them.
#
authRecovery() {
    echo "Performing auth key recovery on hosts $(hostname)" >&2
    local osds=$(getLocalOSDs)

    if [ -z "$osds" ]; then
        echo "No local OSDs found" >&2
        exit_or_return
        return 1
    fi

    for osdNumber in $osds; do
        echo "Recovering auth key for OSD $osdNumber" >&2
        local authKey=$(getLocalAuthKeyForOSD $osdNumber)

        if [ -z "$authKey" ]; then
            echo "ERROR: Failed to get auth key for OSD $osdNumber" >&2
            exit_or_return
            return 1
        fi

        setAuthKeyForOSD $osdNumber $authKey
    done

    echo "Auth key recovery complete" >&2
    echo "" >&2
}


#
#   Given the location of an OSD directory, get the OSD auth key
#
getLocalAuthKeyForOSD() {
    local osdNumber=$1
    # We should not use pipe directs but we check the variable gets defined which is why we use it
    local cmd="cat /var/lib/rook/rook-ceph/set*/ceph-${osdNumber}/keyring | grep key | awk '{print \$3}'"

    echo "Getting auth key for $osdNumber" >&2
    execute_command "$cmd"

    if [ "$CMD_OUT" == "" ]; then
        echo "Failed to get auth key for OSD $osdNumber" >&2
        echo "ERROR: $CMD_ERR" >&2
        exit_or_return
        return 1
    fi
    
    local authKey=$CMD_OUT
    echo "Auth key for OSD $osdNumber is $authKey" >&2
    echo $authKey
    echo "" >&2
}

#
#
#
setAuthKeyForOSD() {
    local osd=$1
    local authKey=$2

    echo "Setting auth key for $osd" >&2

    #
    #   Exec into the rook-ceph-tools and create a tmp file with the OSD key. The run ceph auth import -i /tmp/keyfile
    #   The tmp file should look like this (for osd.0 with key AQBLNPtl/oaYHhAATq9Z8VHWggy1y4AXrJsmdQ==):
    #   [osd.0]
    #    key = AQBLNPtl/oaYHhAATq9Z8VHWggy1y4AXrJsmdQ==
    #    caps mgr = "allow profile osd"
    #    caps mon = "allow profile osd"
    #    caps osd = "allow *"

    local tmpFile=$(mktemp)
    echo "[osd.$osd]" > $tmpFile
    echo "
    key = $authKey
    caps mgr = \"allow profile osd\"
    caps mon = \"allow profile osd\"
    caps osd = \"allow *\"" >> $tmpFile

    echo "Created tmp file $tmpFile with auth key config" >&2

    local toolsPod=$(getCephToolsPod)

    if [ -z "$toolsPod" ]; then
        echo "Failed to get the ceph tools pod" >&2
        exit_or_return
        return 1
    fi

    #
    #   Copy the file to the rook-ceph-tools pod
    #
    kubectlCmd "-n rook-ceph cp $tmpFile $toolsPod:/tmp/keyfile"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to copy the keyfile to the rook-ceph-tools pod" >&2
        echo "ERROR: $CMD_ERR" >&2
        exit_or_return
        return 1
    fi

    #
    #  Run the ceph auth import command
    #
    kubectlCmd "exec -n rook-ceph deploy/rook-ceph-tools -- ceph auth import -i /tmp/keyfile"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to set the auth key for OSD" >&2
        echo "ERROR: $CMD_ERR" >&2
        exit_or_return
        return 1
    fi

    echo "Auth key set for OSD $osd" >&2

}

##################################################################################################
#  Tools Pod Functions
##################################################################################################


#
#   Function to get the tools pod name.
#
function getCephToolsPod() {
    echo "Getting ceph tools pod" >&2
    kubectlCmd "-n rook-ceph get pods -l app=rook-ceph-tools -o jsonpath='{.items[0].metadata.name}'"

    echo "Ceph tools pod is $CMD_OUT" >&2
    echo $CMD_OUT
    echo "" >&2
}

##################################################################################################
#  Storage Functions
##################################################################################################
function storageStats() {
    echo "Printing Storage Stats"
    #if .usage."rgw.main".size_kb_actual != null then (.usage."rgw.main".size_kb_actual / 1024) else .usage."rgw.main".size_kb_actual end])
    local cmd="-n rook-ceph exec deploy/rook-ceph-tools -- radosgw-admin bucket stats | jq -r '[\"BucketName\",\"NoOfObjects\",\"SizeInMB\"], [\"--------------------\",\"------\",\"------\"], (.[] | [.bucket, .usage.\"rgw.main\".\"num_objects\", if .usage.\"rgw.main\".size_kb_actual != null then (.usage.\"rgw.main\".size_kb_actual/ 1024 | floor) else .usage.\"rgw.main\".size_kb_actual end]) | @tsv' | column -ts \$'\\t'"
    kubectlCmd "$cmd"

    echo ""
    echo "$CMD_OUT"
    echo ""

    #
    #  Get the storage capacity using the cephcluster status
    #
    local cmd="-n rook-ceph get cephcluster -o jsonpath='{.items[0].status.ceph.capacity}' | jq -r '[\"MB Total\", \"MB Available\", \"MB Used\"],[.bytesTotal / (1024 * 1024),.bytesAvailable / (1024 * 1024), .bytesUsed / (1024 * 1024) ] | @tsv' | column  -ts $'\t'"
    kubectlCmd "$cmd"

    

    echo ""
    echo "$CMD_OUT"
    echo ""
}