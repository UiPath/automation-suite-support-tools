#!/bin/bash

SCRIPTDIR=$(dirname "$0")
if [ -d "$SCRIPTDIR/../../Modules/" ]; then
    MODULESPATH="$SCRIPTDIR/../../Modules"
else
    MODULESPATH="$SCRIPTDIR/Modules"
fi

source $MODULESPATH/systemUtils/systemUtils.sh
source $MODULESPATH/cephUtils/cephUtils.sh
source $MODULESPATH/kubectlUtils/kubectlUtils.sh

if [ -d "$SCRIPTDIR/../../Configs/" ]; then
    CONFIGS="$SCRIPTDIR/../../Configs/"
else
    CONFIGS="$SCRIPTDIR/Configs/"
fi

CONFIGSOURCE="$CONFIGS/s3Utils"

function getAiCenterDataUsage() {
    echo "Creating S3 pod in uipath-infra" >&2
    local yamlfile="$CONFIGS/s3Utils/s3AiCenterUsage.yaml"

    kubectlCmd "-n uipath-infra delete pod ai-center-usage || true"

    yamlfile=$(setupS3Yaml $yamlfile)

    local cmd="apply -f $yamlfile"
    kubectlCmd "$cmd"

    # Create a loop to wait for the pod to be Completed
    local podStatus=""
    local count=0
    #
    # Wait until the pod is ready using wait command with kubectl
    #
    local cmd="-n uipath-infra wait --for=condition=Ready pod/ai-center-usage --timeout=3m"
    kubectlCmd "$cmd"

    echo ""
    echo "The following command could take some time to complete." >&2
    echo "To see the progess, execute the same command in a different terminal" >&2

    local cmd="-n uipath-infra logs ai-center-usage -f"
    kubectlCmd "$cmd"
    echo "Pod completed" >&2
    echo ""
    # Set pipefail to catch errors in the logs command

    set -o pipefail
    local cmd="logs -n uipath-infra ai-center-usage | grep s3"
    kubectlCmd "$cmd"
    set +o pipefail

    local logs=$CMD_OUT

    kubectlCmd "delete -f $yamlfile"
    echo "Printing Usage by Folder "
    echo ""
    for item in $logs; do
        # Check if the item is a bucket name
        if [[ $item == "s3"* ]]; then
            echo -n "$item "
            echo ""
        else
            echo -n "$item "
        fi
    done

}

function setupS3Yaml() {
    local yamlfile=$1

    local utilsImage=$(getsfUtilsImage)
    if [ -z "$utilsImage" ]; then
        echo "Error: Unable to get the utils image." >&2
        exit 1
    fi

    #
    #   Update the utils image in the yaml file. Don't modify the original file.
    #
    local tmpfile=$(mktemp /tmp/s3.XXXXXX)
    local cmd="cp $yamlfile $tmpfile"
    execute_command "$cmd"

    if [ $CMD_EXIT_CODE -ne 0 ]; then
        echo "Error: Unable to copy the yaml file." >&2
        exit 1
    fi

    cmd="sed -i \"s|UTILS_IMAGE|$utilsImage|g\" $tmpfile"

    execute_command "$cmd"

    if [ $CMD_EXIT_CODE -ne 0 ]; then
        echo "Error: Unable to update the yaml file." >&2
        exit 1
    fi

    echo $tmpfile
}