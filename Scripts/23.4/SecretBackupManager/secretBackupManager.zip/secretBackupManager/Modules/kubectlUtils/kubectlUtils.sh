#!/bin/bash


SCRIPTDIR=$(dirname "$0")
if [ -d "$SCRIPTDIR/../../Modules/" ]; then
    MODULESPATH="$SCRIPTDIR/../../Modules"
else
    MODULESPATH="$SCRIPTDIR/Modules/"
fi

source $MODULESPATH/systemUtils/systemUtils.sh

#
# Source KUBECTL
#
export PATH="$PATH:/usr/local/bin:/var/lib/rancher/rke2/bin"
export KUBECONFIG="/etc/rancher/rke2/rke2.yaml"


createPod () {
    local podName=$1
    local podYaml=$2

    local cmd="kubectl create -f $podYaml"
    execute_command "$cmd"
}

copyIntoPod () {
    local podName=$1
    local sourceFile=$2
    local destinationFile=$3

    local cmd="kubectl cp $sourceFile $podName:$destinationFile"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to copy file $sourceFile to pod $podName" >&2
        echo "ERROR: $CMD_ERR" >&2
        echo "Try manually running the following command: $cmd" >&2
        exit_or_return
        return 1
    fi
}

getsfUtilsImage () {
    local cmd="kubectl -n uipath-infra get cronjobs fluentd-logs-cleanup  -o jsonpath='{.spec.jobTemplate.spec.template.spec.containers[0].image}'"
    execute_command "$cmd"
    
    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to get sf utils image" >&2
        echo "ERROR: $CMD_ERR" >&2
        echo "Try manually running the following command: $cmd" >&2
        exit_or_return
        return 1
    fi
}

# Function to backup config map 
backupConfigMap() {
    local namespace=$1
    local configMapName=$2
    local configFile=$3
    echo "Backing up config map $2 in namespace $1 to $3" >&2

    local cmd="kubectl -n $namespace get configmap $configMapName -o json"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to backup configmap $configMapName in namespace $namespace" >&2
        echo "ERROR: $CMD_ERR" >&2
        exit_or_return
        return 1
    fi

    # Remove the uid, resourceVersion and creationTimestamp from the secret. This command will not fail if CMD_OUT is null but that would be unlikely.
    echo "Removing Metadata from the config map" >&2
    echo "Executing: echo ConfigVar | jq 'del(.metadata.uid, .metadata.resourceVersion, .metadata.creationTimestamp)'  > $configFile" >&2
    echo $CMD_OUT | jq 'del(.metadata.uid, .metadata.resourceVersion, .metadata.creationTimestamp)'  > $configFile

    if [ "$?" -ne 0 ]; then
        echo "Failed to backup configmap $configMap in namespace $namespace" >&2
        exit_or_return
        return 1
    fi
}

# TODO add function to get single secret

# Get all secrets names in a namespace
# TODO untested
# getSecrets () {
#     local namespace=$1
#     local cmd="kubectl -n $namespace get secrets  -o=jsonpath='{.items[*].metadata.name}'"
#     execute_command "$cmd"

#     if [ "$CMD_EXIT_CODE" -ne 0 ]; then
#         echo "Failed to get secrets in namespace $namespace" >&2
#         echo "ERROR: $CMD_ERR" >&2
#         exit_or_return
#         return 1
#     fi

#     echo "$CMD_OUT"
# }

# Function to backup a secret. It takes in the namespace, name and the file to backup the secret to.
backupSecret() {
    
    local namespace=$1
    local secretName=$2
    local secretFile=$3
    echo "Backing up secret $2 in namespace $1 to $3" >&2

    local cmd="kubectl -n $namespace get secret $secretName -o json"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to backup secret $secretName in namespace $namespace" >&2
        echo "ERROR: $CMD_ERR" >&2
        exit_or_return
        return 1
    fi

    # Remove the uid, resourceVersion and creationTimestamp from the secret. This command will not fail if CMD_OUT is null but that would be unlikely.
    echo "Removing Metadata from the secret" >&2
    echo "Executing: echo SecretVar | jq 'del(.metadata.uid, .metadata.resourceVersion, .metadata.creationTimestamp)'  > $secretFile" >&2
    echo $CMD_OUT | jq 'del(.metadata.uid, .metadata.resourceVersion, .metadata.creationTimestamp)'  > $secretFile

    if [ "$?" -ne 0 ]; then
        echo "Failed to backup secret $secretName in namespace $namespace" >&2
        exit_or_return
        return 1
    fi
}

# Function to get the uipath version
# TODO untested
# getUiPathVersion() {
#     local cmd="kubectl -n uipath-infra get cm | grep service-fabric-core"
#     execute_command "$cmd"

#     if [ "$CMD_EXIT_CODE" -ne 0 ]; then
#         echo "Failed to find service-fabric-core* in namespace uipath-infra" >&2
#         echo "ERROR: $CMD_ERR" >&2
#         exit_or_return
#         return 1
#     fi

#     # Parse the output for the version. It will always be in the format service-fabric-core-<version>. Store this as a variable
#     local version=$(echo "$CMD_OUT" | grep -oP "service-fabric-core-\K[0-9]+\.[0-9]+\.[0-9]+")
#     echo "$version"
# }

# Function to get the uipath enabled services
getUiPathEnabledServices() {
    echo "Getting the list of enabled services from uipath-infra namespace"
    local cmd="kubectl -n uipath-infra get cm | grep service-fabric-core"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to find service-fabric-core-<version> cm in namespace uipath-infra" >&2
        echo "ERROR: $CMD_ERR" >&2
        exit_or_return
        return 1
    fi

    local configmap=$(echo "$CMD_OUT" | awk '{print $1}')

    # Get the list of enabled services from the configmap. Its loacated at data.enabled-services
    cmd="kubectl -n uipath-infra get cm $configmap -o=jsonpath='{.data.ENABLED_SERVICE_LIST}'"
    execute_command "$cmd"


    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to get enabled services in namespace uipath-infra" >&2
        echo "ERROR: $CMD_ERR" >&2
        exit_or_return
        return 1
    fi

    # Parese the output for the list of enabled services. Its a , seperated list. We want it as an array
    local enabledServices=$(echo "$CMD_OUT" | tr ',' '\n')

    echo "$enabledServices"

}

kubectlCmd () {
    local cmd="kubectl $1"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to execute kubectl command: $cmd" >&2
        echo "ERROR: $CMD_ERR" >&2
        exit_or_return
        return 1
    fi
}