#!/bin/bash

# Determine the directory of the script
SCRIPTDIR=$(dirname "$0")

# Set the path to modules
if [ -d "$SCRIPTDIR/../../Modules/" ]; then
    MODULESPATH="$SCRIPTDIR/../../Modules"
else
    MODULESPATH="$SCRIPTDIR/Modules/"
fi

# Source required modules
source "$MODULESPATH/systemUtils/systemUtils.sh"
source "$MODULESPATH/kubectlUtils/kubectlUtils.sh"

# Flag for -backup and -restore
BACKUP=0
RESTORE=0
RESTORE_FILE=""

# Parse command line options. The options are backup, in which case we do a backup of secrets. If restore is set, we restore the secrets. Restore should have a file as input 
parseArgs () {
    while [ "$#" -gt 0 ]; do
        case "$1" in
            -backup)
                BACKUP=1
                ;;
            -restore)
                RESTORE=1
                # Check if there's an additional argument for the file
                if [ -z "$2" ] || [ "${2:0:1}" == "-" ]; then
                    echo "Error: File argument missing for -restore option" >&2
                    echo "Usage: $0 -backup|-restore <file>" >&2
                    exit 1
                else
                    RESTORE_FILE="$2"
                    shift
                fi
                ;;
            *)
                echo "Unknown option: $1" >&2
                echo "Usage: $0 -backup|-restore <file>" >&2
                exit 1
                ;;
        esac
        shift
    done
}

# Make sure only one flag is set
checkFlags () {
    if [ $BACKUP -eq 1 ] && [ $RESTORE -eq 1 ]; then
        echo "Only one flag can be set" >&2
        echo "Usage: $0 -backup|-restore" >&2
        exit 1
    fi

    if [ $BACKUP -eq 0 ] && [ $RESTORE -eq 0 ]; then
        echo "One flag must be set" >&2
        echo "Usage: $0 -backup|-restore" >&2
        exit 1
    fi
}

# Function to backup secrets
backupSecrets () {

    echo "Backing up the secrets" >&2
    echo "" >&2

    local enabledServices=( $(getUiPathEnabledServices) )

    if [ -z "$enabledServices" ]; then
        echo "Failed to get the enabled services" >&2
        exit 1
    fi

    # We need to go through and create a list of secrets for what is enabled.
    local non_argo_managed_secrets=()
    local non_argo_managed_configmaps=()

    if [[ " ${enabledServices[@]} " =~ "orchestrator" ]]; then
        non_argo_managed_secrets+=("identity-client-audit" "identity-client-aimetering" "identity-client-aievents" "identity-generated-secrets" "identity-token-signing-certificate" "identity-client-robot" "orchestrator-generated-secrets" "identity-client-orchestrator" "identity-client-la" "identity-client-lrm" "identity-client-oms" "identity-client-messagebus" "identity-client-resourcecatalog" "identity-client-notificationservice" "robotube-generated-secrets")
        non_argo_managed_configmaps+=("orchestrator-customconfig" "identity-service-customconfig" "location-service-configmap")
    fi
    
    # TODO - Check this for aicenter
    if [[ " ${enabledServices[@]} " =~ "aicenter" ]]; then
        non_argo_managed_secrets+=("identity-client-aifabric" "identity-client-aimetering" "identity-client-aievents" "identity-client-audit" "identity-generated-secrets" "identity-token-signing-certificate" "identity-client-la" "identity-client-lrm" "identity-client-oms" "identity-client-messagebus" "identity-client-resourcecatalog")
    fi

    if [[ " ${enabledServices[@]} " =~ "testmanager" ]]; then
        non_argo_managed_secrets+=("identity-client-testmanager" "testmanager-generated-secrets")
    fi

    if [[ " ${enabledServices[@]} " =~ "automationops" ]]; then
       non_argo_managed_secrets+=("identity-client-automationops")
    fi

    if [[ " ${enabledServices[@]} " =~ "actioncenter" ]]; then
        non_argo_managed_secrets+=("identity-client-insights" "insights-generated-secrets")
    fi

    if [[ " ${enabledServices[@]} " =~ "documentunderstanding" ]]; then
        non_argo_managed_secrets+=("identity-client-documentunderstanding")
    fi
    
    if [[ " ${enabledServices[@]} " =~ "apps" ]]; then
        non_argo_managed_secrets+=("identity-client-ba" "businessapps-generated-secrets")
    fi
    
    if [[ " ${enabledServices[@]} " =~ "dataservice" ]]; then
        non_argo_managed_secrets+=("identity-client-dataservice" "dataservice-secrets")
    fi

    if [[ " ${enabledServices[@]} " =~ "asrobots" ]]; then
        non_argo_managed_secrets+=("identity-client-serverless" "asrobots-generated-secrets")
    fi

    # Remove duplicate secrets
    non_argo_managed_secrets=($(echo "${non_argo_managed_secrets[@]}" | tr ' ' '\n' | sort -u | tr '\n' ' '))

    # remove duplicate configmaps
    non_argo_managed_configmaps=($(echo "${non_argo_managed_configmaps[@]}" | tr ' ' '\n' | sort -u | tr '\n' ' '))

    # Make backup file in the current directory
    local backup_file="uipath-secrets-config.yaml"
    echo "Backing up the secrets to $backup_file" >&2
    echo "" >&2

    > "$backup_file"

    if [ ! -f "$backup_file" ]; then
        echo "Failed to create backup file $backup_file" >&2
        echo "Check permissions on the directory: $PWD" >&2
        exit 1
    fi

    echo "Collecting Secrets" >&2
    echo "" >&2

    for secret in "${non_argo_managed_secrets[@]}"; do
        # Make temp file
        local temp_file=$(mktemp)
        backupSecret "uipath" "$secret" $temp_file

        # Append the secret to the backup file. We need to add ---.
        # We should need error checking since all files should be writable.
        echo "Appending secret to backup file" >&2
        echo "---" >> "$backup_file"
        cat $temp_file >> "$backup_file"

        if [ "$?" -ne 0 ]; then
            echo "Failed to append secret $secret" >&2
            exit 1
        fi
        
        rm $temp_file
        if [ "$?" -ne 0 ]; then
            echo "Failed to remove temp file $temp_file" >&2
            exit 1
        fi
        echo "Removed temp file $temp_file" >&2
        echo "" >&2

    done

    echo "Collecting ConfigMaps" >&2
    echo "" >&2

    for configmap in "${non_argo_managed_configmaps[@]}"; do
        # Make temp file
        local temp_file=$(mktemp)
        backupConfigMap "uipath" "$configmap" $temp_file

        # Append the secret to the backup file. We need to add ---.
        # We should need error checking since all files should be writable.
        echo "Appending configmap to backup file" >&2
        echo "---" >> "$backup_file"
        cat $temp_file >> "$backup_file"

        if [ "$?" -ne 0 ]; then
            echo "Failed to append secret $configmap" >&2
            exit 1
        fi
        
        rm $temp_file
        if [ "$?" -ne 0 ]; then
            echo "Failed to remove temp file $temp_file" >&2
            exit 1
        fi

        echo "Removed temp file $temp_file" >&2
        echo "" >&2
    done

    echo "Backup complete" >&2

    echo "Backup file: $backup_file" >&2
}

# REstore the secrets from the input file
restoreSecrets() {
    echo "Restoring secrets from $RESTORE_FILE" >&2
    local cmd="apply -f $RESTORE_FILE"
    kubectlCmd "$cmd"

    echo "Restore complete" >&2
}

# Check if the script is run with sudo or not
if [ "$EUID" -ne 0 ]; then
    echo "Please run as root or with sudo" >&2
    exit 1
fi

# Parse command line arguments
parseArgs "$@"

# Check flags
checkFlags


if [ $BACKUP -eq 1 ]; then
    backupSecrets
elif [ $RESTORE -eq 1 ]; then
    restoreSecrets
fi
